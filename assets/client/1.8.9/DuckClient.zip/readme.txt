1. Go to the version folder in your Minecraft folder.
2. Create a folder that name "DuckClient".
3. Put all of the files into the "DuckClient" folder.